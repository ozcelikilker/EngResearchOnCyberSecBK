function render(data, url) {
  const result = data ? data.result : 'unknown';
  const score = data ? Math.round(data.confidence * 100) : 0;
  const features = data ? data.triggered_features : [];

  const icons = { safe: '✅', suspicious: '⚠️', phishing: '🚫', unknown: '❓' };
  const titles = { safe: 'Bu site güvenli', suspicious: 'Dikkatli olun', phishing: 'Phishing tespit edildi!', unknown: 'Analiz edilemedi' };
  const btnLabels = { safe: 'Güvenli ✓', suspicious: 'Devam Et', phishing: 'Bu Sayfadan Çık!', unknown: 'Kapat' };
  const btnClasses = { safe: 'btn-safe', suspicious: 'btn-suspicious', phishing: 'btn-danger', unknown: 'btn-ghost' };
  const scoreLabels = { safe: 'Güvenlik Skoru', suspicious: 'Risk Skoru', phishing: 'Tehlike Skoru', unknown: 'Skor' };
  const statusLabels = { safe: 'GÜVENLİ', suspicious: 'ŞÜPHELİ', phishing: 'TEHLİKELİ', unknown: 'BİLİNMİYOR' };
  const dotColors = { safe: '#00d68f', suspicious: '#ffaa00', phishing: '#ff3366', unknown: '#888' };

  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="band band-${result}"></div>
    <div class="header">
      <div class="logo">🔥 PHOENIX</div>
      <div class="header-right">
        <span class="status-dot" style="background:${dotColors[result]}"></span>
        <span class="status-text ${result}">${statusLabels[result]}</span>
        <button class="settings-btn" id="settings-btn" title="Ayarlar">⚙️</button>
      </div>
    </div>
    <div class="main">
      <div class="result-row">
        <div class="result-icon icon-${result}">${icons[result]}</div>
        <div>
          <div class="result-title ${result}">${titles[result]}</div>
          <div class="result-url">${url || ''}</div>
        </div>
      </div>
      <div class="score-section">
        <div class="score-header">
          <span class="score-label">${scoreLabels[result]}</span>
          <span class="score-value ${result}">%${score}</span>
        </div>
        <div class="bar-track"><div class="bar-fill fill-${result}" style="width:${score}%"></div></div>
      </div>
      ${features.length > 0 ? `
        <div class="features-label">Tespit edilen özellikler</div>
        ${features.map(f => `
          <div class="feature-item">
            <div class="feature-dot" style="background:${dotColors[result]}"></div>
            ${f}
          </div>
        `).join('')}
      ` : ''}
    </div>
    <div class="actions">
      <button class="btn btn-ghost" id="close-btn">Kapat</button>
      <button class="btn ${btnClasses[result]}" id="main-btn">${btnLabels[result]}</button>
    </div>
    <div class="footer">
      <span class="footer-text">${new Date().toLocaleTimeString('tr-TR')}</span>
      <span class="footer-text">PHOENIX DNN v1.0</span>
    </div>
  `;

  document.getElementById('close-btn').addEventListener('click', () => window.close());

  document.getElementById('settings-btn').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
    window.close();
  });

  const mainBtn = document.getElementById('main-btn');
  if (result === 'phishing') {
    mainBtn.addEventListener('click', () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.remove(tabs[0].id);
        window.close();
      });
    });
  } else {
    mainBtn.addEventListener('click', () => window.close());
  }
}

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (!tabs[0]) return;
  const tabId = tabs[0].id;
  const url = tabs[0].url;

  chrome.storage.sync.get(['phoenixSettings'], (items) => {
    const autoAnalyze = (items.phoenixSettings ?? {}).autoAnalyze ?? true;

    if (!autoAnalyze) {
      // Otomatik analiz kapalı — devre dışı ekranı göster
      document.getElementById('app').innerHTML = `
        <div class="band band-unknown"></div>
        <div class="header">
          <div class="logo">🔥 PHOENIX</div>
          <div class="header-right">
            <span class="status-dot" style="background:#888"></span>
            <span class="status-text unknown">DEVRE DIŞI</span>
            <button class="settings-btn" id="settings-btn" title="Ayarlar">⚙️</button>
          </div>
        </div>
        <div class="main" style="text-align:center;padding:28px 16px">
          <div style="font-size:36px;margin-bottom:12px">⏸️</div>
          <div style="font-size:14px;font-weight:700;color:#888;margin-bottom:8px">Otomatik Analiz Kapalı</div>
          <div style="font-size:11px;color:#444;line-height:1.6">Analiz özelliğini kullanmak için<br>ayarlardan etkinleştirin.</div>
        </div>
        <div class="actions">
          <button class="btn btn-ghost" id="close-btn">Kapat</button>
          <button class="btn btn-ghost" id="settings-btn-2" style="color:#7B5EA7;border-color:#7B5EA733">⚙️ Ayarları Aç</button>
        </div>
        <div class="footer">
          <span class="footer-text">${new Date().toLocaleTimeString('tr-TR')}</span>
          <span class="footer-text">PHOENIX DNN v1.0</span>
        </div>
      `;
      document.getElementById('close-btn').addEventListener('click', () => window.close());
      document.getElementById('settings-btn').addEventListener('click', () => {
        chrome.runtime.openOptionsPage(); window.close();
      });
      document.getElementById('settings-btn-2').addEventListener('click', () => {
        chrome.runtime.openOptionsPage(); window.close();
      });
      return;
    }

    // Otomatik analiz açık — normal akış
    chrome.storage.local.get([`result_${tabId}`], (items) => {
      const data = items[`result_${tabId}`];
      if (data) {
        render(data, url);
      } else {
        fetch('http://localhost:5000/predict', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: url })
        })
        .then(r => r.json())
        .then(data => render(data, url))
        .catch(() => render(null, url));
      }
    });
  });
});