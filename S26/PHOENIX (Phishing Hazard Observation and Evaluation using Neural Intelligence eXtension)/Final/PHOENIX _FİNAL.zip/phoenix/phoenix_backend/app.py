from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import pickle
import tensorflow as tf
import sqlite3
from urllib.parse import urlparse
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, BatchNormalization

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

def build_model():
    m = Sequential([
        Dense(64, activation='relu', input_shape=(10,)),
        BatchNormalization(),
        Dropout(0.3),
        Dense(32, activation='relu'),
        Dropout(0.2),
        Dense(1, activation='sigmoid')
    ])
    m.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return m

model = build_model()
model.load_weights('model2_weights.weights.h5')

with open('scaler2.pkl', 'rb') as f:
    scaler = pickle.load(f)

def init_db():
    conn = sqlite3.connect('analysis.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS analysis_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        url TEXT NOT NULL,
        result TEXT NOT NULL,
        confidence REAL NOT NULL,
        risk_score INTEGER NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')
    conn.commit()
    conn.close()

init_db()

def extract_features(url):
    parsed = urlparse(url)
    domain = parsed.netloc.lower()

    UsingIP = 1 if domain.replace('.','').replace(':','').isdigit() else -1
    LongURL = 1 if len(url) > 75 else (-1 if len(url) < 54 else 0)
    ShortURL = 1 if any(x in domain for x in ['bit.ly','tinyurl','goo.gl','t.co','ow.ly']) else -1
    Symbol = 1 if '@' in url else -1
    Redirecting = 1 if url.count('//') > 1 else -1
    PrefixSuffix = -1 if '-' in domain else 1
    SubDomains = 1 if domain.count('.') > 3 else (0 if domain.count('.') == 3 else -1)
    HTTPS = 1 if parsed.scheme == 'https' else (-1 if parsed.scheme == 'http' else 1)
    NonStdPort = 1 if any(f':{p}' in url for p in ['8080','8443','4443','9090']) else -1
    InfoEmail = 1 if 'mailto:' in url else -1

    return [UsingIP, LongURL, ShortURL, Symbol, Redirecting,
            PrefixSuffix, SubDomains, HTTPS, NonStdPort, InfoEmail]

def get_triggered_features(url, features):
    triggered = []

    if features[0] == 1:
        triggered.append('IP adresi kullanıyor (alan adı yok)')
    if features[1] == 1:
        triggered.append(f'URL çok uzun ({len(url)} karakter)')
    if features[2] == 1:
        triggered.append('URL kısaltma servisi kullanıyor')
    if features[3] == 1:
        triggered.append("URL'de @ işareti var")
    if features[4] == 1:
        triggered.append('Çoklu yönlendirme (//) içeriyor')
    if features[5] == -1:
        parsed = urlparse(url)
        triggered.append(f'Domain adında tire var: {parsed.netloc}')
    if features[6] == 1:
        parsed = urlparse(url)
        triggered.append(f'Fazla subdomain ({parsed.netloc.count(".")} nokta)')
    if features[7] == -1:
        triggered.append('HTTPS kullanılmıyor (güvensiz bağlantı)')
    if features[8] == 1:
        triggered.append('Standart dışı port kullanıyor')
    if features[9] == 1:
        triggered.append('Mail yönlendirmesi (mailto) içeriyor')

    suspicious_words = ['login','verify','secure','account','paypal',
                        'confirm','signin','password','banking','update']
    found = [w for w in suspicious_words if w in url.lower()]
    if found:
        triggered.append(f'Şüpheli kelimeler: {", ".join(found)}')

    if not triggered:
        triggered.append('Bilinen phishing örüntüsü tespit edilmedi')
        triggered.append('HTTPS protokolü aktif')

    return triggered[:4]

def save_to_db(url, result, confidence, risk_score):
    try:
        conn = sqlite3.connect('analysis.db')
        c = conn.cursor()
        c.execute('SELECT COUNT(*) FROM analysis_history')
        count = c.fetchone()[0]
        if count >= 1000:
            c.execute('DELETE FROM analysis_history WHERE id IN (SELECT id FROM analysis_history ORDER BY id ASC LIMIT 100)')
        c.execute('INSERT INTO analysis_history (url, result, confidence, risk_score) VALUES (?, ?, ?, ?)',
                  (url, result, confidence, risk_score))
        conn.commit()
        conn.close()
    except:
        pass

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    if not data or 'url' not in data:
        return jsonify({'error': 'URL gerekli'}), 400

    url = data['url']

    try:
        features = extract_features(url)
        features_scaled = scaler.transform([features])
        score = float(model.predict(features_scaled, verbose=0)[0][0])

        if score >= 0.85:
            result = 'phishing'
        elif score >= 0.20:
            result = 'suspicious'
        else:
            result = 'safe'

        if result == 'safe':
            display_confidence = round(1 - score, 4)
            display_risk = int((1 - score) * 100)
        else:
            display_confidence = round(score, 4)
            display_risk = int(score * 100)

        triggered = get_triggered_features(url, features)
        save_history = data.get('saveHistory', True)
        if save_history:
            save_to_db(url, result, display_confidence, display_risk)
        return jsonify({
            'url': url,
            'result': result,
            'confidence': display_confidence,
            'risk_score': display_risk,
            'triggered_features': triggered
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/history', methods=['GET'])
def history():
    conn = sqlite3.connect('analysis.db')
    c = conn.cursor()
    c.execute('SELECT url, result, confidence, risk_score, timestamp FROM analysis_history ORDER BY timestamp DESC LIMIT 50')
    rows = c.fetchall()
    conn.close()
    return jsonify([{'url': r[0], 'result': r[1], 'confidence': r[2], 'risk_score': r[3], 'timestamp': r[4]} for r in rows])

@app.route('/history/clear', methods=['POST'])
def clear_history():
    conn = sqlite3.connect('analysis.db')
    c = conn.cursor()
    c.execute('DELETE FROM analysis_history')
    conn.commit()
    conn.close()
    return jsonify({'status': 'cleared'})

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'model': 'PHOENIX DNN v1.0'})

@app.route('/paypal-secure-login/verify')
def fake_phishing():
    return '''<!DOCTYPE html>
<html lang="tr">
<head><meta charset="UTF-8"><title>PayPal - Güvenli Giriş</title>
<style>
body { font-family: Arial; background: #f5f5f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
.card { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); width: 360px; }
.logo { color: #003087; font-size: 28px; font-weight: bold; margin-bottom: 20px; }
input { width: 100%; padding: 12px; margin: 8px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
button { width: 100%; padding: 12px; background: #0070ba; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; margin-top: 10px; }
</style></head>
<body>
<div class="card">
  <div class="logo">PayPal</div>
  <h3>Hesabınıza giriş yapın</h3>
  <input type="email" placeholder="E-posta veya telefon numarası">
  <input type="password" placeholder="Şifre">
  <button>Giriş Yap</button>
  <p style="text-align:center;margin-top:15px"><a href="#">Şifremi unuttum</a></p>
</div>
</body></html>'''

if __name__ == '__main__':
    app.run(host='localhost', port=5000, debug=True)