// Sayfa geçişleri
document.querySelectorAll('.menu-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    item.classList.add('active');
    document.getElementById('page-' + item.dataset.page).classList.add('active');
    if (item.dataset.page === 'history') loadHistory();
  });
});

// Ayarları kaydet
function saveSettings() {
  const settings = {
    autoAnalyze: document.getElementById('auto-analyze').checked,
    autoPopup: document.getElementById('auto-popup').checked,
    warnSuspicious: document.getElementById('warn-suspicious').checked,
    saveHistory: document.getElementById('save-history').checked,
  };
  chrome.storage.sync.set({ phoenixSettings: settings }, () => {
    const btn = document.getElementById('save-btn');
    btn.textContent = '✓ Kaydedildi!';
    setTimeout(() => { btn.textContent = '💾 Kaydet'; }, 2000);
  });
}

// Ayarları yükle
chrome.storage.sync.get(['phoenixSettings'], (items) => {
  const s = items.phoenixSettings;
  if (!s) return;
  document.getElementById('auto-analyze').checked = s.autoAnalyze ?? true;
  document.getElementById('auto-popup').checked = s.autoPopup ?? true;
  document.getElementById('warn-suspicious').checked = s.warnSuspicious ?? true;
  document.getElementById('save-history').checked = s.saveHistory ?? true;
});

// Geçmişi yükle
function loadHistory() {
  fetch('http://localhost:5000/history')
    .then(r => r.json())
    .then(rows => {
      document.getElementById('total-count').textContent = rows.length;
      document.getElementById('safe-count').textContent = rows.filter(r => r.result === 'safe').length;
      document.getElementById('phish-count').textContent = rows.filter(r => r.result === 'phishing').length;
      document.getElementById('susp-count').textContent = rows.filter(r => r.result === 'suspicious').length;

      const tbody = document.getElementById('history-body');
      if (!rows.length) {
        tbody.innerHTML = '<tr><td colspan="4" class="empty">Henüz analiz kaydı yok</td></tr>';
        return;
      }
      tbody.innerHTML = rows.map(r => `
        <tr>
          <td title="${r.url}">${r.url}</td>
          <td><span class="badge b-${r.result}">${r.result === 'safe' ? '✅ Güvenli' : r.result === 'phishing' ? '🚫 Phishing' : '⚠️ Şüpheli'}</span></td>
          <td>%${Math.round(r.confidence * 100)}</td>
          <td style="color:#555">${(r.timestamp || '').slice(0, 19)}</td>
        </tr>
      `).join('');
    })
    .catch(() => {
      document.getElementById('history-body').innerHTML =
        '<tr><td colspan="4" class="empty" style="color:#ff3366">API bağlantısı yok</td></tr>';
    });
}

// Geçmişi temizle
function clearHistory() {
  if (!confirm('Tüm analiz geçmişi silinecek. Emin misiniz?')) return;
  fetch('http://localhost:5000/history/clear', { method: 'POST' })
    .then(() => loadHistory())
    .catch(() => alert('API bağlantısı yok'));
}

// Kaydet butonu
document.getElementById('save-btn').addEventListener('click', saveSettings);

// Geçmişi temizle butonu
document.getElementById('clear-btn') && document.getElementById('clear-btn').addEventListener('click', clearHistory);

// API durumu
function checkAPI() {
  fetch('http://localhost:5000/health')
    .then(() => {
      document.getElementById('api-dot').className = 'status-dot dot-on';
      document.getElementById('api-text').textContent = 'API Aktif';
      document.getElementById('api-text').style.color = '#00d68f';
    })
    .catch(() => {
      document.getElementById('api-dot').className = 'status-dot dot-off';
      document.getElementById('api-text').textContent = 'API Kapalı';
      document.getElementById('api-text').style.color = '#ff3366';
    });
}
checkAPI();
setInterval(checkAPI, 5000);