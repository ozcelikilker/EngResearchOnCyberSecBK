chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url &&
      !tab.url.startsWith('chrome://') &&
      !tab.url.startsWith('chrome-extension://')) {
    chrome.storage.sync.get(['phoenixSettings'], (items) => {
      const autoAnalyze = (items.phoenixSettings ?? {}).autoAnalyze ?? true;
      if (!autoAnalyze) return;
      analyzeURL(tab.url, tabId, items.phoenixSettings ?? {});
    });
  }
});

async function analyzeURL(url, tabId, settings) {
  const autoPopup      = settings.autoPopup      ?? true;
  const warnSuspicious = settings.warnSuspicious ?? true;
  const saveHistory    = settings.saveHistory    ?? true;

  let analyzeUrl = url;
  if (url.includes('localhost:5000/paypal-secure-login')) {
    analyzeUrl = 'http://paypal-secure-login.xyz/verify';
  } else if (url.includes('localhost:5000/test/suspicious')) {
    analyzeUrl = 'http://login-secure.net';
  }
  try {
    const response = await fetch('http://localhost:5000/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: analyzeUrl, saveHistory })
    });
    const data = await response.json();

    let color = '#00d68f';
    let text = '✓';
    if (data.result === 'phishing') { color = '#ff3366'; text = '!'; }
    else if (data.result === 'suspicious') { color = '#ffaa00'; text = '?'; }

    chrome.action.setBadgeText({ text, tabId });
    chrome.action.setBadgeBackgroundColor({ color, tabId });
    chrome.storage.local.set({ [`result_${tabId}`]: data });

    // Banner göster — autoPopup kapalıysa hiç inject etme
    // warnSuspicious kapalıysa şüpheli için inject etme
    const shouldInject =
      autoPopup && (
        data.result === 'safe' ||
        data.result === 'phishing' ||
        (data.result === 'suspicious' && warnSuspicious)
      );

    if (shouldInject) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: injectBanner,
          args: [data]
        });
      } catch(e) {}
    }

  } catch (error) {
    chrome.action.setBadgeText({ text: '−', tabId });
    chrome.action.setBadgeBackgroundColor({ color: '#888888', tabId });
  }
}

function injectBanner(data) {
  if (document.getElementById('phoenix-banner')) return;

  const result = data.result;
  const score = Math.round(data.confidence * 100);

  const colors = {
    safe: { bg: '#00d68f', text: '#001a0f', icon: '✅' },
    suspicious: { bg: '#ffaa00', text: '#1a0f00', icon: '⚠️' },
    phishing: { bg: '#ff3366', text: '#ffffff', icon: '🚫' }
  };
  const c = colors[result];

  const style = document.createElement('style');
  style.textContent = `
    @keyframes phoenixSlideDown {
      from { transform: translateY(-100%); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    @keyframes phoenixSlideUp {
      from { transform: translateY(0); opacity: 1; }
      to { transform: translateY(-100%); opacity: 0; }
    }
  `;
  document.head.appendChild(style);

  const banner = document.createElement('div');
  banner.id = 'phoenix-banner';
  banner.style.cssText = `
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    z-index: 2147483647 !important;
    background: ${c.bg} !important;
    color: ${c.text} !important;
    padding: 14px 20px !important;
    font-family: 'Segoe UI', sans-serif !important;
    font-size: 14px !important;
    font-weight: 600 !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    box-shadow: 0 2px 12px rgba(0,0,0,0.3) !important;
    animation: phoenixSlideDown 0.3s ease !important;
  `;

  if (result === 'safe') {
    banner.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px">
        <span style="font-size:18px">${c.icon}</span>
        <span>🔥 PHOENIX — Bu site güvenli (Güvenlik Skoru: %${score})</span>
      </div>
      <span style="font-size:12px;opacity:0.8">3 saniye içinde kapanacak...</span>
    `;
    document.body.prepend(banner);
    setTimeout(() => {
      banner.style.animation = 'phoenixSlideUp 0.3s ease';
      setTimeout(() => banner.remove(), 300);
    }, 3000);

  } else if (result === 'phishing') {
    let countdown = 3;
    banner.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px">
        <span style="font-size:18px">${c.icon}</span>
        <span id="phoenix-text">🔥 PHOENIX — PHİSHİNG TESPİT EDİLDİ! Bu sekme ${countdown} saniye içinde kapatılacak. (Tehlike: %${score})</span>
      </div>
    `;
    document.body.prepend(banner);

    const interval = setInterval(() => {
      countdown--;
      const el = document.getElementById('phoenix-text');
      if (el) el.textContent = `🔥 PHOENIX — PHİSHİNG TESPİT EDİLDİ! Bu sekme ${countdown} saniye içinde kapatılacak. (Tehlike: %${score})`;
      if (countdown <= 0) {
        clearInterval(interval);
        chrome.runtime.sendMessage({ action: 'closeTab' });
      }
    }, 1000);

    document.getElementById('phoenix-stay') && document.getElementById('phoenix-stay').addEventListener('click', () => {
      clearInterval(interval);
      banner.style.animation = 'phoenixSlideUp 0.3s ease';
      setTimeout(() => banner.remove(), 300);
    });

  } else if (result === 'suspicious') {
    banner.innerHTML = `
      <div style="display:flex;align-items:center;gap:10px">
        <span style="font-size:18px">${c.icon}</span>
        <span>🔥 PHOENIX — Şüpheli site! Dikkatli olun. (Risk: %${score})</span>
      </div>
      <div style="display:flex;gap:8px">
        <button id="phoenix-leave" style="background:rgba(0,0,0,0.2);border:1px solid rgba(0,0,0,0.3);color:${c.text};padding:6px 14px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600;">Geri Dön</button>
        <button id="phoenix-continue" style="background:rgba(0,0,0,0.15);border:1px solid rgba(0,0,0,0.3);color:${c.text};padding:6px 14px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600;">Devam Et</button>
      </div>
    `;
    document.body.prepend(banner);

    document.getElementById('phoenix-leave').addEventListener('click', () => window.history.back());
    document.getElementById('phoenix-continue').addEventListener('click', () => {
      banner.style.animation = 'phoenixSlideUp 0.3s ease';
      setTimeout(() => banner.remove(), 300);
    });
  }
}

// Sekme kapat
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.action === 'closeTab' && sender.tab) {
    chrome.tabs.remove(sender.tab.id);
  }
});